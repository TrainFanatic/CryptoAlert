# CryptoAlert
Find the details of the cyptocurrencies!
In order to use CryptoAlert, double-click the icon of the executable called "CryptoAlert"
You need a coinmarketcap API ID which you can find [here](https://pro.coinmarketcap.com)
You will also *need* an internet connection
